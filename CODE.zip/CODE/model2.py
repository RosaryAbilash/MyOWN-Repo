import pandas as pd
import numpy as np
import pickle
from statsmodels.tsa.seasonal import STL

# Load your dataset
data = pd.read_csv('wagon_data_combined.csv')
data['Date'] = pd.to_datetime(data['Date'], format='%d-%m-%Y')  # Specify the correct date format

# Preprocess 'Maintenance Type' data
maintenance_mapping = {'Regular Inspection': 1, 'Component Replacement': 2, 'Repair': 3}
data['Maintenance Type'] = data['Maintenance Type'].map(maintenance_mapping)

# Train the STL model for 'Maintenance Type'
stl_model_maintenance = STL(data['Maintenance Type'], seasonal=13)  # Adjust seasonal parameter based on data frequency
result_maintenance = stl_model_maintenance.fit()

# Save the trained model as a pickle file
with open('maintenance_stl_model.pkl', 'wb') as f:
    pickle.dump(result_maintenance, f)
