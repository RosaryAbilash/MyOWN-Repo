import pandas as pd
import numpy as np
import pickle
from sklearn.metrics import mean_absolute_error, mean_squared_error

# Load your dataset
data = pd.read_csv('wagon_data_combined.csv')
data['Date'] = pd.to_datetime(data['Date'], format='%d-%m-%Y')  # Specify the correct date format

# List of variables
variables = ['Load Transported', 'Demand', 'Energy Consumed']

# Dictionary to store evaluation metrics for each variable
evaluation_metrics = {}

# Evaluate performance for each variable
for variable in variables:
    # Load the trained STL model
    with open(f'{variable.replace(" ", "_")}_stl_model.pkl', 'rb') as f:
        stl_model = pickle.load(f)

    # Perform decomposition to extract trend component
    trend_component = stl_model.trend

    # Extract the actual values from the dataset
    actual_values = data[variable]

    # Calculate residuals (difference between actual and trend component)
    residuals = actual_values - trend_component

    # Calculate evaluation metrics
    mae = mean_absolute_error(actual_values, trend_component)
    mse = mean_squared_error(actual_values, trend_component)
    rmse = np.sqrt(mse)

    # Store evaluation metrics in the dictionary
    evaluation_metrics[variable] = {'MAE': mae, 'MSE': mse, 'RMSE': rmse}

# Print evaluation metrics for all variables
for variable, metrics in evaluation_metrics.items():
    print(f"Variable: {variable}")
    print("Mean Absolute Error (MAE):", metrics['MAE'])
    print("Mean Squared Error (MSE):", metrics['MSE'])
    print("Root Mean Squared Error (RMSE):", metrics['RMSE'])
    print()
