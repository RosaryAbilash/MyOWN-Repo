import numpy as np
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score

# Generate dummy target labels (binary classification)
np.random.seed(0)
y_true = np.random.randint(0, 2, 100)  # Random true labels (0 or 1)

# Generate dummy predictions for STL model (performing better)
stl_predictions = y_true.copy()  # Assume STL model predicts perfectly
stl_predictions[::3] = 1 - stl_predictions[::3]  # Introduce some errors to simulate imperfections

# Generate dummy predictions for LSTM model (performing worse)
lstm_predictions = np.random.randint(0, 2, 100)  # Random predictions for LSTM model

# Calculate confusion matrix and other metrics for STL model
stl_conf_matrix = confusion_matrix(y_true, stl_predictions)
stl_accuracy = accuracy_score(y_true, stl_predictions)
stl_precision = precision_score(y_true, stl_predictions)
stl_recall = recall_score(y_true, stl_predictions)
stl_f1 = f1_score(y_true, stl_predictions)

# Calculate confusion matrix and other metrics for LSTM model
lstm_conf_matrix = confusion_matrix(y_true, lstm_predictions)
lstm_accuracy = accuracy_score(y_true, lstm_predictions)
lstm_precision = precision_score(y_true, lstm_predictions)
lstm_recall = recall_score(y_true, lstm_predictions)
lstm_f1 = f1_score(y_true, lstm_predictions)

print("STL Model Metrics:")
print("Confusion Matrix:\n", stl_conf_matrix)
print("Accuracy:", stl_accuracy)
print("Precision:", stl_precision)
print("Recall:", stl_recall)
print("F1 Score:", stl_f1)
print()

print("LSTM Model Metrics:")
print("Confusion Matrix:\n", lstm_conf_matrix)
print("Accuracy:", lstm_accuracy)
print("Precision:", lstm_precision)
print("Recall:", lstm_recall)
print("F1 Score:", lstm_f1)
