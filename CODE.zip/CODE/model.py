from statsmodels.tsa.seasonal import STL
import pandas as pd
import matplotlib.pyplot as plt
import pickle

# Load your dataset
data = pd.read_csv('wagon_data_combined.csv')
data['Date'] = pd.to_datetime(data['Date'], format='%d-%m-%Y')  # Specify the correct date format
data.set_index('Date', inplace=True)

# Train the STL model for each variable and save as pickle files
variables = ['Load Transported', 'Demand', 'Energy Consumed']

for variable in variables:
    # Train the STL model
    stl_model = STL(data[variable], seasonal=13)  # Adjust seasonal parameter based on data frequency
    result = stl_model.fit()
    
    # Save the trained model as a pickle file
    with open(f'{variable}_stl_model.pkl', 'wb') as f:
        pickle.dump(result, f)
    
    # Plot the decomposition
    fig = result.plot()
    plt.title(f'{variable} Decomposition')
    plt.show()
