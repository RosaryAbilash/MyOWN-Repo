import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load your dataset
data = pd.read_csv('wagon_data_combined.csv')
data['Date'] = pd.to_datetime(data['Date'], format='%d-%m-%Y')  # Specify the correct date format
data.set_index('Date', inplace=True)

# Plot load transported over time
plt.figure(figsize=(12, 6))
plt.plot(data.index, data['Load Transported'], label='Load Transported')
plt.title('Load Transported over Time')
plt.xlabel('Date')
plt.ylabel('Load Transported')
plt.legend()
plt.grid(True)
plt.show()

# Plot demand over time
plt.figure(figsize=(12, 6))
plt.plot(data.index, data['Demand'], label='Demand')
plt.title('Demand over Time')
plt.xlabel('Date')
plt.ylabel('Demand')
plt.legend()
plt.grid(True)
plt.show()

# Plot energy consumed over time
plt.figure(figsize=(12, 6))
plt.plot(data.index, data['Energy Consumed'], label='Energy Consumed')
plt.title('Energy Consumed over Time')
plt.xlabel('Date')
plt.ylabel('Energy Consumed')
plt.legend()
plt.grid(True)
plt.show()

# Plot maintenance type distribution
plt.figure(figsize=(8, 6))
sns.countplot(data=data, x='Maintenance Type')
plt.title('Distribution of Maintenance Types')
plt.xlabel('Maintenance Type')
plt.ylabel('Count')
plt.xticks(rotation=45)
plt.show()
